Bool sna_init_scrn(ScrnInfoPtr scrn, int entity_num);
